<?php $__env->startSection('container'); ?>
    <div class="card-body">
        <?php if(session()->has('success')): ?>
            <div class="mt-4 alert alert-primary alert-dismissible fade show" role="alert">
                <p>Successs Menambahkan Data!</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>



        <h1>Tambah Barang</h1>
        <div class="row">
            <div class="col">
                <form class="contact-form form-squared-borders" action="/save-barang" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <label class="form-label mb-1 text-2">Nama Barang</label>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" data-msg-required="Please enter your name." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama"
                                required="" value="<?php echo e(old('nama')); ?>" placeholder="Nama Barang">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col">
                            <label class="form-label">Kategori</label>
                            <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="custom-select-1">
                                <select
                                    class="form-select form-control h-auto py-2  <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-msg-required="Please select a city." name="kategori" required="">
                                    <option value="">Pilih Kategori</option>
                                    <option value="1">Minuman</option>
                                    <option value="2">Makanan Ringan</option>
                                    <option value="3">Sabun Mandi</option>
                                    <option value="4">Sabun Cuci</option>
                                    <option value="5">Produk Rokok</option>
                                    <option value="6">Es Krim</option>
                                    <option value="7">Lain-Lain</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <label class="form-label mb-1 text-2">Harga Beli</label>
                            <?php $__errorArgs = ['hargaBeli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['hargaBeli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hargaBeli" value="<?php echo e(old('hargaBeli')); ?>" placeholder="0">
                        </div>
                        <div class="col-6">
                            <label class="form-label mb-1 text-2">Harga Jual</label>
                            <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hargaJual" value="<?php echo e(old('hargaJual')); ?>" placeholder="0">
                        </div>

                        <div class="col-12">
                            <label class="form-label mb-1 text-2">Stok</label>
                            <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                value="<?php echo e(old('stok')); ?>"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stok"
                                placeholder="0">
                        </div>
                    </div>



                    <div class="mt-4 row">
                        <div class="form-group col">
                            <input type="submit" value="Save Barang" class="w-100 btn-lg btn-primary"
                                data-loading-text="Loading...">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.mainTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Job\Toko Merah\TokoMerah\resources\views/barang/tambahBarang.blade.php ENDPATH**/ ?>