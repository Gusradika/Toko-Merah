<?php $__env->startSection('container'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Table Laporan Penjualan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-striped dataTable" id="dataTable" width="100%" cellspacing="0"
                                role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr role="row">
                                        <th rowspan="1" colspan="1">No</th>
                                        <th rowspan="1" colspan="1">Tanggal</th>
                                        <th rowspan="1" colspan="1">Jumlah Barang Terjual</th>
                                        <th rowspan="1" colspan="1">Jumlah Pelanggan</th>
                                        <th rowspan="1" colspan="1">Total Pendapatan Kotor</th>
                                        <th rowspan="1" colspan="1">Keuntungan Bersih</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="">
                                            <td class="sorting_1"><?php echo e($data['nomor']); ?></td>
                                            <td><?php echo e($data['tanggal']); ?>


                                            </td>
                                            <td><?php echo e($data['jumlahBarang']); ?></td>
                                            <td><?php echo e($data['jumlahPelanggan']); ?></td>
                                            <td><span class="text-danger"><?php echo e($data['kotor']); ?></span></td>
                                            <td><?php echo e($data['bersih']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-center">
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.mainTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Job\Toko Merah\TokoMerah\resources\views/laporan/laporan.blade.php ENDPATH**/ ?>