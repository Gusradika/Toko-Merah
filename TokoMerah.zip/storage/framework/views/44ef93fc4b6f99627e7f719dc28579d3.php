<?php $__env->startSection('container'); ?>
    <div class="card-body">
        <?php if(session()->has('success')): ?>
            <div class="mt-4 alert alert-primary alert-dismissible fade show" role="alert">
                <p>Successs Mengganti Data!</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <h1>Edit Barang</h1>
        <div class="row">
            <div class="col">
                <form class="contact-form form-squared-borders" action="/updateBarang" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <label class="form-label mb-1 text-2">Nama Barang</label>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="hidden" class="form-control text-3 h-auto py-2" name="id" required=""
                                value="<?php echo e($barang->id); ?>" readonly>
                            <input type="text" data-msg-required="Please enter your name." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama"
                                required="" value="<?php echo e($barang->nama); ?>" placeholder="Nama Barang">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col">
                            <label class="form-label">Kategori</label>
                            <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="custom-select-1">
                                <select
                                    class="form-select form-control h-auto py-2  <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-msg-required="Please select a city." name="kategori" required="">
                                    <option value="">Pilih Kategori</option>
                                    <option value="1" <?php if($barang->kategori_id == 1): ?> selected <?php endif; ?>>Minuman
                                    </option>
                                    <option value="2" <?php if($barang->kategori_id == 2): ?> selected <?php endif; ?>>Makanan Ringan
                                    </option>
                                    <option value="3" <?php if($barang->kategori_id == 3): ?> selected <?php endif; ?>>Sabun Mandi
                                    </option>
                                    <option value="4"<?php if($barang->kategori_id == 4): ?> selected <?php endif; ?>>Sabun Cuci
                                    </option>
                                    <option value="5"<?php if($barang->kategori_id == 5): ?> selected <?php endif; ?>>Produk Rokok
                                    </option>
                                    <option value="6"<?php if($barang->kategori_id == 6): ?> selected <?php endif; ?>>Es Krim</option>
                                    <option value="6"<?php if($barang->kategori_id == 7): ?> selected <?php endif; ?>>Lain-Lain
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <label class="form-label mb-1 text-2">Harga Beli</label>
                            <?php $__errorArgs = ['hargaBeli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['hargaBeli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hargaBeli" value="<?php echo e(old('hargaBeli', $barang->hargaBeli)); ?>" placeholder="0">
                        </div>
                        <div class="col-6">
                            <label class="form-label mb-1 text-2">Harga Jual</label>
                            <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hargaJual" value="<?php echo e(old('hargaJual', $barang->hargaJual)); ?>" required
                                placeholder="0">
                        </div>

                        <div class="col-12">
                            <label class="form-label mb-1 text-2">Stok</label>
                            <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="number" data-msg-required="Please enter the subject." maxlength="100"
                                value="<?php echo e(old('stok', $barang->stok)); ?>"
                                class="form-control text-3 h-auto py-2  <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stok"
                                placeholder="0">
                        </div>
                    </div>



                    <div class="mt-4 row">
                        <div class="form-group col">
                            <input type="submit" value="Save Barang" class="w-100 btn-lg btn-primary"
                                data-loading-text="Loading...">
                        </div>
                    </div>
                </form>
                <form class="contact-form form-squared-borders" action="/deleteBarang" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control text-3 h-auto py-2" name="id" required=""
                        value="<?php echo e($barang->id); ?>" readonly>
                    <button type="submit" class="w-100 btn-lg btn-danger">Delete Barang</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.mainTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Job\Toko Merah\TokoMerah\resources\views/barang/editBarang.blade.php ENDPATH**/ ?>