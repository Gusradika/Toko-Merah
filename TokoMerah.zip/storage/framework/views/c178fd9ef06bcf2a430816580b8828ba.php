<?php $__env->startSection('container'); ?>
    <div class="row">
        <?php if(session()->has('successTambah')): ?>
            <div class="mt-4 alert alert-primary alert-dismissible fade show" role="alert">
                <p>Successs Mengedit Data!</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('successDelete')): ?>
            <div class="mt-4 alert alert-danger alert-dismissible fade show" role="alert">
                <p>Successs Delete Data!</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="">
            <span class="badge badge-primary p-2"><?php echo e($jumlah); ?> Barang</span>
            <span class="badge badge-danger p-2"><?php echo e($jumlahX); ?> Barang Tanpa Harga Beli</span>

            <h1>List Barang : <?php echo e($active); ?></h1>

        </div>
    </div>
    <label for="cari">Cari Barang : </label>
    <form action="/cari-barang" method="get">
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Username" id="cari" aria-label="Username"
                aria-describedby="basic-addon1" name="cari">
            <button class="btn btn-primary" type="submit">
                Cari</button>
        </div>
    </form>

    <div class="mb-3">
        <a href="/list-barang">
            <button class="btn-sm btn-dark" <?php if($active == 'Semua'): ?> disabled <?php endif; ?>>Semua Barang</button>
        </a>
        <a href="/list-barang-minuman">
            <button class="btn-sm btn-secondary" <?php if($active == 'Minuman'): ?> disabled <?php endif; ?>>Minuman</button>
        </a>
        <a href="/list-barang-makanan">
            <button class="btn-sm btn-secondary" <?php if($active == 'Makanan'): ?> disabled <?php endif; ?>>Makanan Ringan</button>
        </a>
        <a href="/list-barang-sabunMandi">
            <button class="btn-sm btn-secondary" <?php if($active == 'Sabun Mandi'): ?> disabled <?php endif; ?>>Sabun Mandi</button>
        </a>
        <a href="/list-barang-sabunCuci">
            <button class="btn-sm btn-secondary"<?php if($active == 'Sabun Cuci'): ?> disabled <?php endif; ?>>Sabun Cuci</button>
        </a>
        <a href="/list-barang-rokok">
            <button class="btn-sm btn-secondary" <?php if($active == 'Rokok'): ?> disabled <?php endif; ?>>Produk Rokok</button>
        </a>
        <a href="/list-barang-es-krim">
            <button class="btn-sm btn-secondary" <?php if($active == 'Es Krim'): ?> disabled <?php endif; ?>>Es Krim</button>
        </a>
        <a href="/list-barang-lain">
            <button class="btn-sm btn-secondary" <?php if($active == 'Lain-Lain'): ?> disabled <?php endif; ?>>Lain-lain</button>
        </a>
    </div>


    <div class="">
        <?php echo e($barang->links('pagination::bootstrap-5')); ?>

    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Table Barang <?php echo e($active); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-striped dataTable" id="dataTable" width="100%" cellspacing="0"
                                role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr role="row">
                                        <th rowspan="1" colspan="1">Id</th>
                                        <th rowspan="1" colspan="1">Nama</th>
                                        <th rowspan="1" colspan="1">Nama Kategori</th>
                                        <th rowspan="1" colspan="1">Harga Beli</th>
                                        <th rowspan="1" colspan="1"><span class="text-danger">Harga Jual</span></th>
                                        <th rowspan="1" colspan="1">Keuntungan</th>
                                        <th rowspan="1" colspan="1">Stok</th>
                                        <th rowspan="1" colspan="1">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="">
                                            <td class="sorting_1"><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->nama); ?>

                                                <?php if($data->profit == 0): ?>
                                                    <span class="badge badge-danger">X</span>
                                                <?php endif; ?>

                                            </td>
                                            <td><span class="p-2 badge bg-dark">
                                                    <?php if($data->kategori_id == 1): ?>
                                                        Minuman
                                                    <?php elseif($data->kategori_id == 2): ?>
                                                        Makanan Ringan
                                                    <?php elseif($data->kategori_id == 3): ?>
                                                        Sabun Mandi
                                                    <?php elseif($data->kategori_id == 4): ?>
                                                        Sabun Cuci
                                                    <?php elseif($data->kategori_id == 5): ?>
                                                        Produk Rokok
                                                    <?php elseif($data->kategori_id == 6): ?>
                                                        Es Krim
                                                    <?php elseif($data->kategori_id == 7): ?>
                                                        Es Krim
                                                    <?php endif; ?>
                                                </span></td>
                                            <td><?php echo e($data->hargaBeli); ?></td>
                                            <td><span class="text-danger"><?php echo e($data->hargaJual); ?></span></td>
                                            <td><?php echo e($data->profit); ?></td>
                                            <td><?php echo e($data->stok); ?></td>
                                            <td>
                                                <a href="/editbarang/<?php echo e($data->id); ?>"><button
                                                        class="btn btn-warning">Edit</button></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-center">
                            <?php echo e($barang->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.mainTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Job\Toko Merah\TokoMerah\resources\views/barang/barang.blade.php ENDPATH**/ ?>